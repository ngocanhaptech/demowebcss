<?php
/**
 * Plugin Name: Flatsome Blog Posts Pro
 * Description: Mở rộng shortcode blog_posts với bộ lọc tác giả, custom post type và filter bar frontend.
 * Version: 1.0.0
 * Author: Anhln
 * Text Domain: flatsome-blog-posts-pro
 * Requires at least: 5.0
 * Requires PHP: 7.4
 */

// Ngăn truy cập trực tiếp
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Định nghĩa hằng số cho plugin
define( 'FBPP_VERSION', '1.0.0' );
define( 'FBPP_PATH', plugin_dir_path( __FILE__ ) );
define( 'FBPP_URL', plugin_dir_url( __FILE__ ) );

/**
 * Class chính của plugin
 */
final class Flatsome_Blog_Posts_Pro {

    /**
     * Instance duy nhất của class
     *
     * @var Flatsome_Blog_Posts_Pro
     */
    private static $instance = null;

    /**
     * Lấy instance của class
     *
     * @return Flatsome_Blog_Posts_Pro
     */
    public static function get_instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
	// Trong __construct()
	private function __construct() {
		$this->includes();
		$this->init_hooks();
	}

	private function includes() {
		require_once FBPP_PATH . 'inc/helpers.php';
		require_once FBPP_PATH . 'inc/shortcodes/ux-blog-posts.php';

		// LUÔN include builder (sẽ tự kiểm tra UX Builder bên trong)
		require_once FBPP_PATH . 'inc/builder/ux-blog-posts-builder.php';
	}

    /**
     * Khởi tạo hooks
     */
    private function init_hooks() {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
        add_action( 'init', array( $this, 'load_textdomain' ) );
    }

    /**
     * Enqueue CSS và JS cho frontend
     */
    public function enqueue_frontend_assets() {
        wp_enqueue_style(
            'fbpp-frontend',
            FBPP_URL . 'assets/css/ux-blog-posts.css',
            array(),
            FBPP_VERSION
        );
    }

    /**
     * Load text domain cho plugin
     */
    public function load_textdomain() {
        load_plugin_textdomain( 'flatsome-blog-posts-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }

    /**
     * Kiểm tra UX Builder có đang hoạt động không
     *
     * @return bool
     */
    private function is_ux_builder_active() {
        return function_exists( 'add_ux_builder_shortcode' );
    }
}

// Khởi tạo plugin
Flatsome_Blog_Posts_Pro::get_instance();