flatsome-blog-posts-pro/
├── flatsome-blog-posts-pro.php   (file chính)
├── assets/
│   └── css/
│       └── ux-blog-posts.css
├── inc/
│   ├── builder/
│   │   └── ux-blog-posts-builder.php
│   ├── shortcodes/
│   │   └── ux-blog-posts.php
│   └── helpers.php
└── template-parts/
    └── ux-blog-posts/
        ├── normal.php
        ├── vertical.php
        └── overlay.php