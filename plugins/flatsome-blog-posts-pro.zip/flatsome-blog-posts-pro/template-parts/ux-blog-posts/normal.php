<?php
/**
 * Blog post template: Normal style
 *
 * @package Flatsome_Blog_Posts_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$classes = array( 'col', 'post-item' );
?>
<div <?php post_class( $classes ); ?>>
    <div class="col-inner">
        <?php if ( has_post_thumbnail() ) : ?>
            <div class="box-image">
                <div class="<?php echo esc_attr( $image_hover ); ?>">
                    <a href="<?php the_permalink(); ?>" class="plain">
                        <?php the_post_thumbnail( 'large' ); ?>
                        <?php if ( $image_overlay ) : ?>
                            <div class="overlay" style="background-color: <?php echo esc_attr( $image_overlay ); ?>"></div>
                        <?php endif; ?>
                    </a>
                </div>
            </div>
        <?php endif; ?>
        
        <div class="box-text box-text-<?php echo esc_attr( $text_align ); ?>">
            <?php if ( 'true' === $show_category ) : ?>
                <div class="post-category is-xxsmall">
                    <?php the_category( ', ' ); ?>
                </div>
            <?php endif; ?>
            
            <div class="box-text-inner blog-post-inner">
                <h5 class="post-title is-<?php echo esc_attr( $title_size ); ?>">
                    <a href="<?php the_permalink(); ?>" class="plain"><?php the_title(); ?></a>
                </h5>
                
                <?php if ( 'true' === $show_excerpt ) : ?>
                    <div class="post-excerpt">
                        <?php echo flatsome_string_limit_words( get_the_excerpt(), intval( $excerpt_length ) ); ?>
                    </div>
                <?php endif; ?>
                
                <div class="post-meta is-small op-8">
                    <?php if ( 'true' === $show_date ) : ?>
                        <span class="post-date"><?php echo get_the_date(); ?></span>
                    <?php endif; ?>
                    
                    <?php if ( 'true' === $show_author ) : ?>
                        <span class="post-author"><?php esc_html_e( 'by', 'flatsome-blog-posts-pro' ); ?> <?php the_author(); ?></span>
                    <?php endif; ?>
                    
                    <?php if ( 'true' === $show_comments ) : ?>
                        <span class="post-comments"><?php comments_number(); ?></span>
                    <?php endif; ?>
                </div>
                
                <?php if ( $readmore ) : ?>
                    <div class="post-readmore">
                        <a href="<?php the_permalink(); ?>" class="button <?php echo esc_attr( $readmore_style ); ?> is-<?php echo esc_attr( $readmore_color ); ?> is-small">
                            <?php echo esc_html( $readmore ); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>