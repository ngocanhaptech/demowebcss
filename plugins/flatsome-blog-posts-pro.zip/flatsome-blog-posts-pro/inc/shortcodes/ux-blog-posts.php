<?php
/**
 * Shortcode: ux_blog_posts
 *
 * @package Flatsome_Blog_Posts_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Render shortcode ux_blog_posts
 *
 * @param array  $atts    Shortcode attributes.
 * @param string $content Shortcode content.
 * @param string $tag     Shortcode tag.
 * @return string
 */
function fbpp_ux_blog_posts_shortcode( $atts, $content = null, $tag = '' ) {
    $default_atts = array(
        // Core attributes
        'style'         => 'normal',
        'columns'       => '3',
        'columns__md'   => '',
        'columns__sm'   => '1',
        'posts'         => '8',
        'image_height'  => '56.25%',
        'image_width'   => '100%',
        'image_radius'  => '',
        'image_hover'   => '',
        'image_overlay' => '',
        'text_align'    => 'left',
        'text_padding'  => '',
        'title_size'    => '',
        'title_style'   => '',
        'show_category' => 'true',
        'show_date'     => 'true',
        'show_excerpt'  => 'true',
        'excerpt_length'=> '15',
        'show_author'   => 'false',
        'show_comments' => 'false',
        'readmore'      => '',
        'readmore_color'=> '',
        'readmore_style'=> '',
        
        // Extended attributes
        'post_type'     => 'post',
        'author'        => '',
        'orderby'       => 'date',
        'order'         => 'DESC',
        'show_filter_bar' => 'true',
        'filter_style'  => 'tabs',
        'filter_align'  => 'center',
        
        // Relay and visibility
        'relay'                => '',
        'relay_control_position'=> '',
        'relay_control_align'  => '',
        'relay_control_result_count' => '',
        'relay_id'             => '',
        'relay_class'          => '',
        'visibility'           => '',
        'class'                => '',
    );

    $atts = shortcode_atts( $default_atts, $atts, $tag );

    // Pagination
    $paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
    if ( get_query_var( 'page' ) ) {
        $paged = get_query_var( 'page' );
    }

    // Lấy filter từ URL
    $filter_author  = isset( $_GET['fbpp_author'] ) ? sanitize_text_field( $_GET['fbpp_author'] ) : '';
    $filter_orderby = isset( $_GET['fbpp_orderby'] ) ? sanitize_text_field( $_GET['fbpp_orderby'] ) : $atts['orderby'];
    $filter_order   = isset( $_GET['fbpp_order'] ) ? sanitize_text_field( $_GET['fbpp_order'] ) : $atts['order'];

    // Build query args
    $args = array(
        'post_type'      => $atts['post_type'],
        'post_status'    => 'publish',
        'posts_per_page' => intval( $atts['posts'] ),
        'paged'          => $paged,
        'orderby'        => $filter_orderby,
        'order'          => $filter_order,
    );

    // Author filter
    if ( ! empty( $filter_author ) && $filter_author !== 'all' ) {
        $args['author'] = intval( $filter_author );
    } elseif ( ! empty( $atts['author'] ) ) {
        $args['author'] = intval( $atts['author'] );
    }

    $query = new WP_Query( $args );

    // Lưu query vào global để dùng trong template
    global $fbpp_query;
    $fbpp_query = $query;

    ob_start();

    // Render filter bar
    if ( 'true' === $atts['show_filter_bar'] ) {
        fbpp_render_filter_bar( $atts, $query );
    }

    // CSS classes cho container
    $classes = array(
        'row',
        'fbpp-posts-wrapper',
        'fbpp-posts-style--' . $atts['style'],
		'large-columns-' . $atts['columns'],
		'medium-columns-' . $atts['columns__md'],
		'small-columns-' . $atts['columns__sm'],
        $atts['class'],
        $atts['visibility'],
    );

    if ( 'normal' !== $atts['style'] ) {
        $classes[] = 'large-columns-' . $atts['columns'];
        if ( $atts['columns__md'] ) {
            $classes[] = 'medium-columns-' . $atts['columns__md'];
        }
        if ( $atts['columns__sm'] ) {
            $classes[] = 'small-columns-' . $atts['columns__sm'];
        }
    }

    $classes = array_filter( $classes );
    $classes = implode( ' ', $classes );


    // Render posts
    if ( $query->have_posts() ) {
        ?>
        <div class="<?php echo esc_attr( $classes ); ?>">
            <?php
            while ( $query->have_posts() ) {
                $query->the_post();
                fbpp_get_template_part( $atts['style'], $atts );
            }
            wp_reset_postdata();
            ?>
        </div>
        <?php

        // Pagination (nếu không dùng relay)
        if ( ! in_array( $atts['relay'], array( 'true', 'pagination', 'load-more', 'prev-next' ), true ) ) {
            fbpp_render_pagination( $query );
        }
    } else {
        echo '<p>' . esc_html__( 'No posts found.', 'flatsome-blog-posts-pro' ) . '</p>';
    }


    return ob_get_clean();
}
add_shortcode( 'ux_blog_posts', 'fbpp_ux_blog_posts_shortcode' );

/**
 * Render filter bar
 *
 * @param array    $atts  Shortcode attributes.
 * @param WP_Query $query WP_Query instance.
 */
function fbpp_render_filter_bar( $atts, $query ) {
    $current_author  = isset( $_GET['fbpp_author'] ) ? sanitize_text_field( $_GET['fbpp_author'] ) : '';
    $current_orderby = isset( $_GET['fbpp_orderby'] ) ? sanitize_text_field( $_GET['fbpp_orderby'] ) : $atts['orderby'];
    $current_order   = isset( $_GET['fbpp_order'] ) ? sanitize_text_field( $_GET['fbpp_order'] ) : $atts['order'];

    $authors = fbpp_get_post_authors( $atts['post_type'] );

    $filter_classes = array(
        'fbpp-filter',
        'fbpp-filter--' . $atts['filter_style'],
        'text-' . $atts['filter_align'],
        'mb-half',
    );
    $filter_classes = implode( ' ', array_filter( $filter_classes ) );

    $base_url = strtok( $_SERVER['REQUEST_URI'], '?' );
    ?>
    <div class="<?php echo esc_attr( $filter_classes ); ?>">
        <form method="get" action="<?php echo esc_url( $base_url ); ?>" class="fbpp-filter__form">
            <?php
            // Giữ lại query params khác
            foreach ( $_GET as $key => $value ) {
                if ( 0 === strpos( $key, 'fbpp_' ) ) {
                    continue;
                }
                echo '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '">';
            }
            ?>

            <?php if ( 'dropdown' === $atts['filter_style'] ) : ?>
                <div class="fbpp-filter__group">
                    <select name="fbpp_author" class="fbpp-filter__select">
                        <option value="all" <?php selected( $current_author, 'all' ); ?>>
                            <?php esc_html_e( 'All Authors', 'flatsome-blog-posts-pro' ); ?>
                        </option>
                        <?php foreach ( $authors as $author_id => $author_name ) : ?>
                            <option value="<?php echo esc_attr( $author_id ); ?>" <?php selected( $current_author, $author_id ); ?>>
                                <?php echo esc_html( $author_name ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php else : ?>
                <div class="fbpp-filter__group fbpp-filter__tabs">
                    <a href="<?php echo esc_url( add_query_arg( 'fbpp_author', 'all', $base_url ) ); ?>" 
                       class="fbpp-filter__tab <?php echo ( 'all' === $current_author || empty( $current_author ) ) ? 'is-active' : ''; ?>">
                        <?php esc_html_e( 'All Authors', 'flatsome-blog-posts-pro' ); ?>
                    </a>
                    <?php foreach ( $authors as $author_id => $author_name ) : ?>
                        <a href="<?php echo esc_url( add_query_arg( 'fbpp_author', $author_id, $base_url ) ); ?>" 
                           class="fbpp-filter__tab <?php echo $current_author == $author_id ? 'is-active' : ''; ?>">
                            <?php echo esc_html( $author_name ); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="fbpp-filter__group">
                <select name="fbpp_orderby" class="fbpp-filter__select">
                    <option value="date" <?php selected( $current_orderby, 'date' ); ?>>
                        <?php esc_html_e( 'Newest', 'flatsome-blog-posts-pro' ); ?>
                    </option>
                    <option value="title" <?php selected( $current_orderby, 'title' ); ?>>
                        <?php esc_html_e( 'Title (A-Z)', 'flatsome-blog-posts-pro' ); ?>
                    </option>
                    <option value="modified" <?php selected( $current_orderby, 'modified' ); ?>>
                        <?php esc_html_e( 'Last Updated', 'flatsome-blog-posts-pro' ); ?>
                    </option>
                    <option value="comment_count" <?php selected( $current_orderby, 'comment_count' ); ?>>
                        <?php esc_html_e( 'Most Commented', 'flatsome-blog-posts-pro' ); ?>
                    </option>
                </select>
                <input type="hidden" name="fbpp_order" value="<?php echo esc_attr( $current_order ); ?>">
            </div>

            <button type="submit" class="fbpp-filter__button button primary is-small">
                <?php esc_html_e( 'Apply', 'flatsome-blog-posts-pro' ); ?>
            </button>
        </form>
    </div>
    <?php
}

/**
 * Load template part cho post item
 *
 * @param string $style Style name.
 * @param array  $atts  Shortcode attributes.
 */
function fbpp_get_template_part( $style, $atts ) {
    $template_file = FBPP_PATH . 'template-parts/ux-blog-posts/' . $style . '.php';

    if ( ! file_exists( $template_file ) ) {
        $template_file = FBPP_PATH . 'template-parts/ux-blog-posts/normal.php';
    }

    if ( file_exists( $template_file ) ) {
        // Truyền biến vào template
        $vars = $atts;
        extract( $vars );
        include $template_file;
    } else {
        // Fallback hiển thị cơ bản
        ?>
        <div class="col post-item">
            <div class="col-inner">
                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="box-image">
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail( 'large' ); ?>
                        </a>
                    </div>
                <?php endif; ?>
                <div class="box-text">
                    <h3 class="post-title">
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h3>
                    <?php if ( 'true' === $atts['show_excerpt'] ) : ?>
                        <div class="post-excerpt">
                            <?php echo flatsome_string_limit_words( get_the_excerpt(), intval( $atts['excerpt_length'] ) ); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
}