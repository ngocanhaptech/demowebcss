<?php
/**
 * UX Builder integration cho ux_blog_posts
 *
 * @package Flatsome_Blog_Posts_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Đăng ký ngay khi file được load, không cần đợi hook
if ( function_exists( 'add_ux_builder_shortcode' ) ) {
    fbpp_register_ux_builder_element();
} else {
    // Nếu UX Builder chưa sẵn sàng, thử lại vào action init (ưu tiên cao)
    add_action( 'init', 'fbpp_register_ux_builder_element', 5 );
}

/**
 * Đăng ký element với UX Builder
 */
function fbpp_register_ux_builder_element() {
    if ( ! function_exists( 'add_ux_builder_shortcode' ) ) {
        return;
    }

    // Fallback thumbnail nếu hàm flatsome_ux_builder_thumbnail không tồn tại
    $thumbnail = function_exists( 'flatsome_ux_builder_thumbnail' )
        ? flatsome_ux_builder_thumbnail( 'blog_posts' )
        : FBPP_URL . 'assets/img/placeholder.svg';

    // Fallback template
    $template = function_exists( 'flatsome_ux_builder_template' )
        ? flatsome_ux_builder_template( 'blog_posts' )
        : '';

    add_ux_builder_shortcode( 'ux_blog_posts', array(
        'name'      => __( 'Blog Posts Pro', 'flatsome-blog-posts-pro' ),
        'category'  => __( 'Content', 'flatsome-blog-posts-pro' ),
        'thumbnail' => $thumbnail,
        'template'  => $template,
        'wrap'      => false,
        'options'   => array(
            // === Post Type ===
            'post_type' => array(
                'type'    => 'select',
                'heading' => __( 'Post Type', 'flatsome-blog-posts-pro' ),
                'default' => 'post',
                'options' => fbpp_get_post_type_options(),
            ),
            'style' => array(
                'type'    => 'select',
                'heading' => __( 'Style', 'flatsome-blog-posts-pro' ),
                'default' => 'normal',
                'options' => array(
                    'normal'   => 'Normal',
                    'vertical' => 'Vertical',
                    'bounce'   => 'Bounce',
                    'push'     => 'Push',
                    'overlay'  => 'Overlay',
                    'shade'    => 'Shade',
                ),
            ),

            // === Author Filter Section ===
            'author_section' => array(
                'type'    => 'group',
                'heading' => __( 'Author Filter', 'flatsome-blog-posts-pro' ),
                'options' => array(
                    'author' => array(
                        'type'    => 'select',
                        'heading' => __( 'Filter by Author', 'flatsome-blog-posts-pro' ),
                        'default' => '',
                        'options' => fbpp_get_author_options(),
                    ),
                    'show_filter_bar' => array(
                        'type'    => 'checkbox',
                        'heading' => __( 'Show Filter Bar', 'flatsome-blog-posts-pro' ),
                        'default' => true,
                    ),
                    'filter_style' => array(
                        'type'       => 'select',
                        'heading'    => __( 'Filter Style', 'flatsome-blog-posts-pro' ),
                        'default'    => 'tabs',
                        'options'    => array(
                            'tabs'     => 'Tabs',
                            'dropdown' => 'Dropdown',
                            'inline'   => 'Inline',
                        ),
                        'conditions' => 'show_filter_bar === "true"',
                    ),
                    'filter_align' => array(
                        'type'       => 'radio-buttons',
                        'heading'    => __( 'Filter Alignment', 'flatsome-blog-posts-pro' ),
                        'default'    => 'center',
                        'options'    => array(
                            'left'   => 'Left',
                            'center' => 'Center',
                            'right'  => 'Right',
                        ),
                        'conditions' => 'show_filter_bar === "true"',
                    ),
                ),
            ),

            // === Query Section ===
            'query_section' => array(
                'type'    => 'group',
                'heading' => __( 'Query', 'flatsome-blog-posts-pro' ),
                'options' => array(
                    'posts' => array(
                        'type'    => 'scrubfield',
                        'heading' => __( 'Posts per page', 'flatsome-blog-posts-pro' ),
                        'default' => '8',
                        'min'     => '1',
                        'max'     => '50',
                    ),
                    'orderby' => array(
                        'type'    => 'select',
                        'heading' => __( 'Order By', 'flatsome-blog-posts-pro' ),
                        'default' => 'date',
                        'options' => array(
                            'date'          => 'Date',
                            'title'         => 'Title',
                            'modified'      => 'Modified',
                            'comment_count' => 'Comment Count',
                            'rand'          => 'Random',
                        ),
                    ),
                    'order' => array(
                        'type'    => 'select',
                        'heading' => __( 'Order', 'flatsome-blog-posts-pro' ),
                        'default' => 'DESC',
                        'options' => array(
                            'DESC' => 'Descending',
                            'ASC'  => 'Ascending',
                        ),
                    ),
                ),
            ),

            // === Layout Section ===
            'layout_section' => array(
                'type'    => 'group',
                'heading' => __( 'Layout', 'flatsome-blog-posts-pro' ),
                'options' => array(
                    'columns' => array(
                        'type'       => 'slider',
                        'heading'    => __( 'Columns (Desktop)', 'flatsome-blog-posts-pro' ),
                        'default'    => '3',
                        'responsive' => true,
                        'max'        => '12',
                        'min'        => '1',
                    ),
                    'columns__md' => array(
                        'type'    => 'slider',
                        'heading' => __( 'Columns (Tablet)', 'flatsome-blog-posts-pro' ),
                        'default' => '',
                        'max'     => '12',
                        'min'     => '1',
                    ),
                    'columns__sm' => array(
                        'type'    => 'slider',
                        'heading' => __( 'Columns (Mobile)', 'flatsome-blog-posts-pro' ),
                        'default' => '',
                        'max'     => '12',
                        'min'     => '1',
                    ),
                ),
            ),

            // === Post Options ===
            'post_options_section' => array(
                'type'    => 'group',
                'heading' => __( 'Post Options', 'flatsome-blog-posts-pro' ),
                'options' => array(
                    'show_category' => array(
                        'type'    => 'checkbox',
                        'heading' => __( 'Show Category', 'flatsome-blog-posts-pro' ),
                        'default' => true,
                    ),
                    'show_date' => array(
                        'type'    => 'checkbox',
                        'heading' => __( 'Show Date', 'flatsome-blog-posts-pro' ),
                        'default' => true,
                    ),
                    'show_author' => array(
                        'type'    => 'checkbox',
                        'heading' => __( 'Show Author', 'flatsome-blog-posts-pro' ),
                        'default' => false,
                    ),
                    'show_comments' => array(
                        'type'    => 'checkbox',
                        'heading' => __( 'Show Comments', 'flatsome-blog-posts-pro' ),
                        'default' => false,
                    ),
                    'show_excerpt' => array(
                        'type'    => 'checkbox',
                        'heading' => __( 'Show Excerpt', 'flatsome-blog-posts-pro' ),
                        'default' => true,
                    ),
                    'excerpt_length' => array(
                        'type'       => 'scrubfield',
                        'heading'    => __( 'Excerpt Length', 'flatsome-blog-posts-pro' ),
                        'default'    => '15',
                        'min'        => '5',
                        'max'        => '100',
                        'conditions' => 'show_excerpt === "true"',
                    ),
                ),
            ),

            // === Advanced ===
            'advanced_section' => array(
                'type'    => 'group',
                'heading' => __( 'Advanced', 'flatsome-blog-posts-pro' ),
                'options' => array(
                    'class' => array(
                        'type'    => 'textfield',
                        'heading' => __( 'CSS Class', 'flatsome-blog-posts-pro' ),
                        'default' => '',
                    ),
                    'visibility' => array(
                        'type'    => 'select',
                        'heading' => __( 'Visibility', 'flatsome-blog-posts-pro' ),
                        'default' => '',
                        'options' => array(
                            ''                      => __( 'Always visible', 'flatsome-blog-posts-pro' ),
                            'hide-for-small'        => __( 'Hide for mobile', 'flatsome-blog-posts-pro' ),
                            'show-for-small'        => __( 'Show for mobile', 'flatsome-blog-posts-pro' ),
                            'hide-for-medium'       => __( 'Hide for tablet', 'flatsome-blog-posts-pro' ),
                            'show-for-medium'       => __( 'Show for tablet', 'flatsome-blog-posts-pro' ),
                            'show-for-large'        => __( 'Show for desktop', 'flatsome-blog-posts-pro' ),
                            'hide-for-large'        => __( 'Hide for desktop', 'flatsome-blog-posts-pro' ),
                        ),
                    ),
                ),
            ),
        ),
    ));
}