<?php
/**
 * Helper functions cho Flatsome Blog Posts Pro
 *
 * @package Flatsome_Blog_Posts_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Lấy danh sách post types public để làm options
 *
 * @return array
 */
function fbpp_get_post_type_options() {
    $post_types = get_post_types( array( 'public' => true ), 'objects' );
    $options    = array();

    foreach ( $post_types as $post_type ) {
        $options[ $post_type->name ] = $post_type->label;
    }

    return $options;
}

/**
 * Lấy danh sách tác giả có bài viết thuộc post type
 *
 * @param string $post_type Post type.
 * @return array
 */
function fbpp_get_post_authors( $post_type = 'post' ) {
    $cache_key = 'fbpp_authors_' . $post_type;
    $authors   = get_transient( $cache_key );

    if ( false !== $authors ) {
        return $authors;
    }

    $args = array(
        'post_type'      => $post_type,
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'fields'         => 'ids',
    );

    $query      = new WP_Query( $args );
    $author_ids = array();

    if ( $query->have_posts() ) {
        foreach ( $query->posts as $post_id ) {
            $author_id = get_post_field( 'post_author', $post_id );
            if ( ! in_array( $author_id, $author_ids, true ) ) {
                $author_ids[] = $author_id;
            }
        }
    }

    $authors = array();
    foreach ( $author_ids as $author_id ) {
        $user = get_userdata( $author_id );
        if ( $user ) {
            $authors[ $author_id ] = $user->display_name;
        }
    }

    asort( $authors );

    set_transient( $cache_key, $authors, DAY_IN_SECONDS );

    return $authors;
}

/**
 * Lấy danh sách tác giả cho select option
 *
 * @return array
 */
function fbpp_get_author_options() {
    $options = array( '' => __( 'All Authors', 'flatsome-blog-posts-pro' ) );
    $users   = get_users( array(
        'who'     => 'authors',
        'orderby' => 'display_name',
        'order'   => 'ASC',
    ) );

    foreach ( $users as $user ) {
        $options[ $user->ID ] = $user->display_name;
    }

    return $options;
}

/**
 * Render pagination
 *
 * @param WP_Query $query WP_Query instance.
 */
function fbpp_render_pagination( $query ) {
    $total_pages  = $query->max_num_pages;
    $current_page = max( 1, get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1 );

    if ( $total_pages <= 1 ) {
        return;
    }

    $prev_arrow = is_rtl() ? '→' : '←';
    $next_arrow = is_rtl() ? '←' : '→';

    $pagination_args = array(
        'base'      => str_replace( 999999999, '%#%', get_pagenum_link( 999999999 ) ),
        'format'    => '?paged=%#%',
        'current'   => $current_page,
        'total'     => $total_pages,
        'mid_size'  => 2,
        'prev_text' => $prev_arrow,
        'next_text' => $next_arrow,
        'type'      => 'list',
    );

    $pagination = paginate_links( $pagination_args );

    if ( $pagination ) {
        echo '<div class="container">';
        echo '<div class="fbpp-pagination">';
        echo $pagination;
        echo '</div>';
        echo '</div>';
    }
}

/**
 * Clear cache khi có post mới được publish
 */
add_action( 'save_post', 'fbpp_clear_author_cache' );
function fbpp_clear_author_cache( $post_id ) {
    $post_type = get_post_type( $post_id );
    delete_transient( 'fbpp_authors_' . $post_type );
}